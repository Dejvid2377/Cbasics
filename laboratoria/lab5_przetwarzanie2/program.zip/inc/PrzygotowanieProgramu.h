#ifndef PRZYGOTOWANIEPROGRAMU_H
#define PRZYGOTOWANIEPROGRAMU_H
#include "ZmiennePomocnicze.h"

/**********************************************************************************
* Funkcje: >>   wyzeruj_opcje     <<                                              *
*          >>   przetwarzaj opcje <<                                              *
*  zawarte w programie zostaly zaimplementowane na wzor wersji opracowanej przez  *
*  autorow ktorzy zgodzili sie udostepnic prawa do ich kopiowania i modyfikacji.  *
*                                                                                 *
*                                           COPYRIGHT (c) 2007-2020 KCiR          *
***********************************************************************************/

/**********************************************************************************
* Funkcja inicjuje strukture wskazywana przez wybor                               *
* PRE:                                                                            *
*      poprawnie zainicjowany argument wybor (!=NULL)                             *
* POST:                                                                           *
*      "wyzerowana" struktura wybor wybranych opcji                               *
***********************************************************************************/
void wyzeruj_opcje(t_opcje * wybor);

/**********************************************************************************
* Funkcja rozpoznaje opcje wywolania programu zapisane w tablicy argv i zapisuje  *
* je w strukturze wybor.                                                          *
* Skladnia opcji wywolania programu:                                              *
*         program {[-i nazwa] [-o nazwa] [-p liczba] [-n] [-r] [-d] }             *
* Argumenty funkcji:                                                              *
*         argc  -  liczba argumentow wywolania wraz z nazwa programu              *
*         argv  -  tablica argumentow wywolania                                   *
*         wybor -  struktura z informacjami o wywolanych opcjach                  *
* PRE:                                                                            *
*      brak                                                                       *
* POST:                                                                           *
*     Funkcja otwiera odpowiednie pliki, zwraca uchwyty do nich w strukturze      *
*      wybór, do tego ustawia na 1 pola dla opcji, ktore poprawnie wystapily w    *
*      linii wywolania programu.                                                  *
*	  Pola opcji nie wystepujacych w wywolaniu ustawione sa na 0;                 *
*	  Zwraca wartosc W_OK (0), gdy wywolanie bylo poprawne lub kod bledu          *
*      zdefiniowany stalymi B_* (<0).                                             *
* UWAGA:                                                                          *
*      funkcja nie sprawdza istnienia i praw dostepu do plikow, w takich          *
*       przypadkach zwracane uchwyty maja wartosc NULL.                           *
***********************************************************************************/
int przetwarzaj_opcje(int argc, char **argv,t_obraz *, t_opcje *);

/************************************************************************************
 * Funkcja rozpoznaje rodzaj obrazu, a nastepnie wczytuje go z pliku do tablicy     *
 *										                                            *
 * \param[in] t_obraz struktura przechowujaca informacje o budowie obrazu           *
 * \param[in] t_opcje struktura przechowujaca dostepne opcje (m.in uchwyt do pliku) *
 * \param[out] t_obraz uzupelniona nowymi danymi                                    *
 * \return liczba wczytanych pikseli						                        *
 ************************************************************************************/
int czytaj(t_obraz *, t_opcje *); 

/************************************************************************************
 * Funkcja zapisuje obraz do nowego pliku                                           *
 *										                                            *
 * \param[in] t_obraz struktura przechowujaca informacje o budowie obrazu           *
 * \param[in] t_opcje struktura przechowujaca dostepne opcje (m.in uchwyt do pliku) *
 * \param[out] t_opcje uzupelnione o dane na temat nowego pliku                     *
 * \return liczba wczytanych pikseli						                        *
 ************************************************************************************/
int zapis (t_obraz *, t_opcje *);

/************************************************************************************
 * Funkcja wyswietla rządany obraz poprzez ingerencje w polecenia systemowe    	    *
 *										                                            *
 * \param[in]  nazwa pliku ktory chcemy wyswietlic                           * 
 * \param[out] wyswietlony obraz                                                    *
 * \return liczba wczytanych pikseli             					                *
 ************************************************************************************/
void wyswietl(t_opcje *);

/************************************************************************************
 * Funkcja wyswietla rządany obraz poprzez ingerencje w polecenia systemowe    	    *
 *										                                            *
 * \param[in]  nazwa pliku ktory chcemy wyswietlic                           * 
 * \param[out] wyswietlony obraz               					                    *
 ************************************************************************************/
void rozpoznaj_blad (int);

/************************************************************************************
 * Funkcja wykonuje konwersje obrazow ppm do formatu pgm                    	    *
 *										                                            *
 * \param[in] tablica z wartosciami pikseli dla formatu ppm                         * 
 * \param[out] nowa tablica, o tej samej nazwie, ale z wartosciami dla formatu pgm  *
 ************************************************************************************/
void konwersja_szarosci(t_obraz *,t_opcje *);

#endif
