#ifndef ZMIENNEPOMOCNICZE_H
#define ZMIENNEPOMOCNICZE_H
#include <stdio.h>
#include <string.h>

#define W_OK 0                   /* wartosc oznaczajaca brak bledow */
#define B_NIEPOPRAWNAOPCJA -1    /* kody bledow rozpoznawania opcji */
#define B_BRAKNAZWY   -2
#define B_BRAKWARTOSCI  -3
#define B_BRAKPLIKU   -4
#define B_KOLORU      -5
#define B_BLEDNYKOLOR -6
#define B_ZLAWARTOSC -7
#define DL_LINII 100

typedef struct {
 int wymx, wymy, szarosci;
 int nowy_wymx;
 int **piksele,**piksele_temp;
 int wspolczynnik; //1 lub 3, zaleznie od formatu pliku
 char znak; //okresla liczbe magiczna
} t_obraz;

/* strukura do zapamietywania opcji podanych w wywolaniu programu */
typedef struct {
  FILE *plik_we, *plik_wy;        /* uchwyty do pliku wej. i wyj. */
  char *nazwa_wej, *nazwa_wyj;    /* nazwy plikow */
/*zmienne pelniace role flag */ 
  int negatyw,progowanie,konturowanie,polprogowanie_czerni,polprogowanie_bieli;
  int zmiana_poziomow,korekcja_gamma,wyswietlenie,konwersja_szarosci;
  int rozmywanie_poziome,rozciaganie,rozmywanie_pionowe;
/*zmienne przechowujace wartosci liczbowe dla funkcji */
  float w_prog,w_progb,w_progc;
  float w_gamma,nowy_bieli,nowy_czerni;
/* zmienne do obslugi przetwarzania opcji kolorow */
  int kolor,wybrano_kolor;
/* dane na temat kolejnosci wykonania opcji */
  char tablica[12]; //tablica o malym rozmiarze (nie trzeba dynamicznej)
  int rozmiar;
} t_opcje;
#endif

/**********************************************************
 *  Dostepne flagi (poprzedzamy znakiem '-') :            *
 *  i [nazwa_pliku] - nazwa pliku wejsciowego             * 
 *  o [nazwa_pliku] - nazwa pliku do zapisu               *
 *  m [kolor]       - wybor koloru przetwarzania:         *
 *                    r - czerwony                        *
 *                    g - zielony                         *
 *                    b - niebieski                       *
 *                    s - konwersja do szarosci           *
 *  p [wartosc]     - progowanie                          *
 *  c [wartosc]     - progowanie czerni                   *
 *  b [wartosc]     - progowanie bieli                    *
 *  g [wartosc]     - konwersja gamma                     *
 *  z [wartosc][wartosc] - zmiana poziomow bieli i czerni *
 *  n   - negatyw                                         *
 *  k   - konturowanie                                    *
 *  x   - rozmywanie poziome                              *
 *  y   - rozmywanie pionowe                              *
 *  r   - rozciaganie                                     *
 *  d   - wyswietlenie                                    *
 *********************************************************/