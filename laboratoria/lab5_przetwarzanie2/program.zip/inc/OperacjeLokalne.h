#ifndef OPERACJELOKALNE_H
#define OPERACJELOKALNE_H
#include "ZmiennePomocnicze.h"

/****************************************************************************
 * Funkcja modyfikuje wartosci pikseli w celu uzyskania efektu konturowania *
 *										                                    *
 * \param[in] obraz_wej struktura opisujaca obraz wejsciowy 	            *
 * \param[in] obraz_wyj struktura do zapisu obrazu wyjsciowego              *   
 * \param[out] obraz_wyj struktura z nowo zapisanymi informacjami           *
 ****************************************************************************/
void konturowanie(t_obraz *,t_opcje *); 

/**********************************************************************************
 * Funkcja modyfikuje wartosci pikseli w celu uzyskania efektu rozmycia poziomego *
 *										                                          *
 * \param[in] obraz_wej struktura opisujaca obraz wejsciowy 	                  *
 * \param[in] obraz_wyj struktura do zapisu obrazu wyjsciowego                    *   
 * \param[out] obraz_wyj struktura z nowo zapisanymi informacjami                 *  
 **********************************************************************************/
void rozmywanie_poziome(t_obraz *,t_opcje *);

/**********************************************************************************
 * Funkcja modyfikuje wartosci pikseli w celu uzyskania efektu rozmycia pionowego *
 *										                                          *
 * \param[in] obraz_wej struktura opisujaca obraz wejsciowy 	                  *
 * \param[in] obraz_wyj struktura do zapisu obrazu wyjsciowego                    *   
 * \param[out] obraz_wyj struktura z nowo zapisanymi informacjami                 * 
 **********************************************************************************/
void rozmywanie_pionowe(t_obraz *,t_opcje *);

/*************************************************************************************
 * Funkcja modyfikuje wartosci pikseli w celu uzyskania efektu rozciągania histogramu*
 *										                                             *
 * \param[in] obraz_wej struktura opisujaca obraz wejsciowy 	                     *
 * \param[in] obraz_wyj struktura do zapisu obrazu wyjsciowego                       * 
 * \param[out] obraz_wyj struktura z nowo zapisanymi informacjami                    * 
 *************************************************************************************/
void rozciaganie(t_obraz *,t_opcje *);

#endif
