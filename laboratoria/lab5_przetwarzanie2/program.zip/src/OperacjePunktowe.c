#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include"OperacjePunktowe.h"


void negatyw (t_obraz *obraz,t_opcje *wybor){
 int i,j;                         /* iteratory tablic */
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */

 for (i=0;i<obraz->wymy;i++) {  /* zmiana wartosci pikseli */
  for (j=kolor;j<obraz->nowy_wymx;j+=stala) {
   obraz->piksele[i][j] = obraz->szarosci-(obraz->piksele[i][j]); 
  }
 }
}

void progowanie(t_obraz *obraz,t_opcje *wybor){                
 int i,j;                         /* iteratory tablic */
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */   
 float liczba = wybor->w_prog * obraz->szarosci / 100; /*wartosc progu w % */

 for (i=0;i<obraz->wymy;i++) {      /*poczatek sekwencji zmiany wartosci pikseli */
  for (j=kolor;j<obraz->nowy_wymx;j+=stala) {
   if (obraz->piksele[i][j] <= liczba)  
    obraz->piksele[i][j] = 0;
   else
    obraz->piksele[i][j] = obraz->szarosci;
  } 
 } 
}

void polprogowanie_czerni(t_obraz *obraz,t_opcje *wybor){               
 int i,j;                         /* iteratory tablic */
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */
 float liczba = wybor->w_progc * obraz->szarosci / 100; /*wartosc progu w % */

 for (i=0;i<obraz->wymy;i++) {    /*poczatek sekwencji zmiany wartosci pikseli */
  for (j=kolor;j<obraz->nowy_wymx;j+=stala) {
   if (obraz->piksele[i][j] <= liczba)
    obraz->piksele[i][j] = 0;
   else
    obraz->piksele[i][j] = obraz->piksele[i][j];
  } 
 } 
}

void polprogowanie_bieli(t_obraz *obraz,t_opcje *wybor){               
 int i,j;                         /* iteratory tablic */
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */  
 float liczba = wybor->w_progb * obraz->szarosci / 100; /* zamiana z % na liczbe */

 for (i=0;i<obraz->wymy;i++) {      /*poczatek sekwencji zmiany wartosci pikseli */
  for (j=kolor;j<obraz->nowy_wymx;j+=stala) {
   if (obraz->piksele[i][j] <= liczba)
    obraz->piksele[i][j] = obraz->piksele[i][j];
   else
    obraz->piksele[i][j] = obraz->szarosci;
  } 
 } 
}

void korekcja_gamma(t_obraz *obraz,t_opcje *wybor) {              
 int i,j;                         /* iteratory tablic */
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */ 
 float gamma = wybor->w_gamma;

 for (i=0;i<obraz->wymy;i++) {   /*poczatek sekwencji zmiany wartosci pikseli */
  for (j=kolor;j<obraz->nowy_wymx;j+=stala) {
   obraz->piksele[i][j]= pow(obraz->piksele[i][j],1/gamma) / pow(obraz->szarosci,(1-gamma)/gamma);
  } 
 } 
}

void zmiana_poziomow(t_obraz *obraz,t_opcje *wybor){              
 int i,j;                         /* iteratory tablic */
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */

 float prog_bieli = wybor->nowy_bieli * obraz->szarosci / 100;     /* wyznaczanie wartosci progow */
 float prog_czerni = wybor->nowy_czerni * obraz->szarosci / 100;

 for (i=0;i<obraz->wymy;i++) {                /*poczatek sekwencji zmiany wartosci pikseli */
  for (j=kolor;j<obraz->nowy_wymx;j+=stala) {
   if (obraz->piksele[i][j] <= prog_czerni)
    obraz->piksele[i][j] = 0;
   else if (obraz->piksele[i][j]>prog_czerni && obraz->piksele[i][j]<prog_bieli)
    obraz->piksele[i][j] = (obraz->piksele[i][j]-prog_czerni) * obraz->szarosci/(prog_bieli-prog_czerni);
   else if (obraz->piksele[i][j]>=prog_bieli)
    obraz->piksele[i][j] = obraz->szarosci;
  } 
 }
}