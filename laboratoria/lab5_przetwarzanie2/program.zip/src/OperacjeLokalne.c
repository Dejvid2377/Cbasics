#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include"OperacjeLokalne.h"

void konturowanie(t_obraz *obraz,t_opcje *wybor){
 int i,j;                         /* iteratory tablic */
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */

 for (i=0;i<obraz->wymy; i++) {                       /* poczatek sekwencji zapisania zmienionej */
  for (j=kolor;j<obraz->nowy_wymx; j+=stala) {       /* wartosci pikseli do nowej tablicy       */
   if (i!=obraz->wymy && j==obraz->nowy_wymx-stala+kolor)               /*ostatnia kolumna */
    obraz->piksele[i][j]=fabs(obraz->piksele[i][j]-obraz->piksele[i][j])
                        +fabs(obraz->piksele[i][j]-obraz->piksele[i][j]);
   else if (i==obraz->wymy-1 && j<obraz->nowy_wymx-stala+kolor)   /* ostatni wiersz */
    obraz->piksele[i][j]=fabs(obraz->piksele[i][j]-obraz->piksele[i][j])
                        +fabs(obraz->piksele[i][j+stala]-obraz->piksele[i][j]);
   else
    obraz->piksele[i][j]=fabs(obraz->piksele[i+1][j]-obraz->piksele[i][j])
                        +fabs(obraz->piksele[i][j+stala]-obraz->piksele[i][j]);
  } /* koniec petli wymx */  
 } /* koniec petli wymy */ 
}


void rozmywanie_poziome(t_obraz *obraz,t_opcje *wybor){
 int i,j;   /* iteratory tablic */
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */

 for (i=0;i<obraz->wymy;i++) {  /* poczatek sekwencji zapisania zmienionej */
  for (j=kolor;j<obraz->nowy_wymx;j+=stala) {      /* wartosci pikseli do nowej tablicy       */
   if (j==kolor)                /* pierwsza kolumna */
    obraz->piksele[i][j] =
     (1.0/3.0)*(obraz->piksele[i][j]+obraz->piksele[i][j]+obraz->piksele[i][j+stala]);
   else if (j==obraz->nowy_wymx-stala+kolor)       /*ostatnia kolumna */
    obraz->piksele[i][j] =
     (1.0/3.0)*(obraz->piksele[i][j-stala]+obraz->piksele[i][j]+obraz->piksele[i][j]);
   else
    obraz->piksele[i][j] = 
     (1.0/3.0)*(obraz->piksele[i][j-stala]+obraz->piksele[i][j]+obraz->piksele[i][j+stala]);
  } /* koniec petli wymx */  
 } /* koniec petli wymy */ 
}

void rozmywanie_pionowe(t_obraz *obraz,t_opcje *wybor){
 int i,j;   /*iteratory tablic*/
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */

 for (i=0;i<obraz->wymy;i++) {  /* poczatek sekwencji zapisania zmienionej */
  for (j=kolor;j<obraz->nowy_wymx;j=j+stala) { /* wartosci pikseli do nowej tablicy       */
   if (i==0)
    obraz->piksele[i][j] =
      (1.0/3.0)*(obraz->piksele[i][j]+obraz->piksele[i][j]+obraz->piksele[i+1][j]);
   else if (i==obraz->wymy-1)
    obraz->piksele[i][j] =
      (1.0/3.0)*(obraz->piksele[i-1][j]+obraz->piksele[i][j]+obraz->piksele[i][j]);
   else
    obraz->piksele[i][j] =
      (1.0/3.0)*(obraz->piksele[i-1][j]+obraz->piksele[i][j]+obraz->piksele[i+1][j]);
  } /* koniec petli wymx */  
 } /* koniec petli wymy */ 
}

void rozciaganie(t_obraz *obraz,t_opcje *wybor){
 int i,j;                         /*iteratory tablic */                 
 int max=0;                       /*inicjalizacja wartosci maksymalnej */
 int min=obraz->szarosci;         /*inicjalizacja wartosci minimalnej  */
 int kolor = wybor->kolor;        /* wartosci od 0 do 2, zaleznie od koloru*/
 int stala = obraz->wspolczynnik; /* wartosc rowna 1 lub 3 */

 for(i=0;i<obraz->wymy;i++) {                   /*sekwencja przeszukiwania tablicy w celu znalezienia */
  for(j=kolor;j<obraz->nowy_wymx;j+=stala) {    /*minimalnej i maksymalnej wartosci pikseli    */
	 if(obraz->piksele[i][j]>max)  
    max = obraz->piksele[i][j];
	 if(obraz->piksele[i][j]<min)  
    min = obraz->piksele[i][j];
	} /* koniec petli wymx */  
 } /* koniec petli wymy */

 for(i=0;i<obraz->wymy;i++) {                    /*poczatek sekwencji kopiowania wartosci pikseli */
  for(j=kolor;j<obraz->nowy_wymx;j+=stala) {     /*do nowego obrazu */
	 obraz->piksele[i][j]=(obraz->piksele[i][j]-min)*(obraz->szarosci/(max-min));
  }
 }
}