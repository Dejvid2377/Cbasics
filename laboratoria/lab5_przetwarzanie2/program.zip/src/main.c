/**********************************************************************************************************
* PROJEKT:  PRZETWARZANIE OBRAZOW CZESC DRUGA                                                             *
* AUTOR:    DAWID KREKORA                                                                                 *
* DATA:     24.01.2021                                                                                    *
* OPIS:     Program umozliwia wykonywanie podstawowych operacji na plikach w formacie PGM oraz PPM.       *
*           W przeciwienstwie do pierwszej czesci nie umowzliwia komunikacji z uzytkownikiem, zastepuja   *
*           ja flagi wywolania programu (wiecej informacji o flagach w pliku "ZmiennePomocnicze.h").      *
***********************************************************************************************************/
#include"OperacjeLokalne.h"
#include"OperacjePunktowe.h"
#include"PrzygotowanieProgramu.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char ** argv) {
 t_opcje opcje;
 t_obraz obraz;
 int kod_bledu,odczytano,zapisano;

/* sprawdzenie czy sa bledy i jakiego typu */
 kod_bledu=przetwarzaj_opcje(argc,argv,&obraz,&opcje);
 rozpoznaj_blad(kod_bledu);

/* odczytanie danych z pliku wyjsciowego */ 
 odczytano=czytaj(&obraz,&opcje);
 fclose(opcje.plik_we);

/* jezeli udalo sie odczytac dane */ 
 if (odczytano) {
  if (opcje.wybrano_kolor==0 && obraz.wymx!=obraz.nowy_wymx) {
   obraz.wspolczynnik=1;
   printf("Nie wybrano opcji koloru.\n");
   printf("Obraz zostanie przetworzony na wszystkich kolorach.\n");
  }

/* przygotowanie programu do nowej sytuacji */
  if (opcje.konwersja_szarosci==1) {
   konwersja_szarosci(&obraz,&opcje);
   obraz.wspolczynnik=1;
   obraz.nowy_wymx=obraz.wymx;
  }

/* petle umozliwiajace wykonanie operacji wedlog wskazanej kolejnosci */
  for(int k=0;k<opcje.rozmiar;k++) {
   switch (opcje.tablica[k]) {
    case 'p': if (opcje.progowanie==1)
               progowanie(&obraz,&opcje);
              break;
    case 'c': if (opcje.polprogowanie_czerni==1)
               polprogowanie_czerni(&obraz,&opcje);
              break;
    case 'b': if (opcje.polprogowanie_bieli==1)
               polprogowanie_bieli(&obraz,&opcje);
              break;
    case 'g': if (opcje.korekcja_gamma==1)
               korekcja_gamma(&obraz,&opcje);
              break;
    case 'z': if (opcje.zmiana_poziomow==1)
               zmiana_poziomow(&obraz,&opcje);
              break;
    case 'n': if (opcje.negatyw==1)
               negatyw(&obraz,&opcje);
              break;
    case 'k': if (opcje.konturowanie==1)
               konturowanie(&obraz,&opcje);
              break;
    case 'x': if (opcje.rozmywanie_poziome==1)
               rozmywanie_poziome(&obraz,&opcje);
              break;
    case 'y': if (opcje.rozmywanie_pionowe==1)
               rozmywanie_pionowe(&obraz,&opcje);
              break;
    case 'r': if (opcje.rozciaganie==1)
               rozciaganie(&obraz,&opcje);
              break;
    default : break;
   } //koniec switch
  } //koniec for
 } //koniec if
 else
  fprintf(stderr,"Blad: Nie udalo sie odczytac danych z pliku");
  
 zapisano=zapis(&obraz,&opcje);
  
 if (zapisano!=0) {
  if (opcje.plik_wy!=stdout) {
   printf("Pomyslnie zapisano plik o nazwie %s\n",opcje.nazwa_wyj);
   if (opcje.wyswietlenie==1)
    wyswietl(&opcje);
  }
 else
  printf("Sekwencja wypisania obrazu na strumien wyjscia zakonczona pomyslnie.\n");
 }

 free(obraz.piksele);
 return kod_bledu;
}