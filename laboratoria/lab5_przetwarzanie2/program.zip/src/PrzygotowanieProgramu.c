#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include"PrzygotowanieProgramu.h"

void wyzeruj_opcje(t_opcje * wybor) {
  wybor->plik_we=NULL;
  wybor->plik_wy=NULL;
  wybor->negatyw=0;
  wybor->konturowanie=0;
  wybor->progowanie=0;
  wybor->polprogowanie_czerni=0;
  wybor->polprogowanie_bieli=0;
  wybor->zmiana_poziomow=0;
  wybor->korekcja_gamma=0;
  wybor->rozmywanie_poziome=0;
  wybor->rozmywanie_pionowe=0;
  wybor->rozciaganie=0;
  wybor->konwersja_szarosci=0;
  wybor->wyswietlenie=0;
  wybor->kolor=0;
  wybor->wybrano_kolor=0;
}

int przetwarzaj_opcje(int argc, char **argv,t_obraz *obraz ,t_opcje *wybor) {
 int i;
 int j=0;

 wyzeruj_opcje(wybor);
 //wybor->plik_wy=stdout;        /* na wypadek gdy nie podano opcji "-o" */
 
 for (i=1; i<argc; i++) {
  if (argv[i][0] != '-')     /* blad: to nie jest opcja - brak znaku "-" */
   return B_NIEPOPRAWNAOPCJA; 
  switch (argv[i][1]) {
   case 'i': if (++i<argc) {   
	            wybor->nazwa_wej=argv[i];
              if (strcmp(wybor->nazwa_wej,"-")==0) 
	             wybor->plik_we=stdin;            
	            else                               
	             wybor->plik_we=fopen(wybor->nazwa_wej,"r"); }
             else 
	            return B_BRAKNAZWY;
             break;
   case 'o': if (++i<argc) {
	           wybor->nazwa_wyj=argv[i];
	           if (strcmp(wybor->nazwa_wyj,"-")==0)
	            wybor->plik_wy=stdout;          
	           else                              
	            wybor->plik_wy=fopen(wybor->nazwa_wyj,"w"); }
            else 
	           return B_BRAKNAZWY;
            break;
   case 'm': if (++i<argc) {
              if(*argv[i]=='r') {
               wybor->kolor=0;  
               wybor->wybrano_kolor++;
              }
              else if(*argv[i]=='g') {
               wybor->kolor=1;
               wybor->wybrano_kolor++;
              }
              else if(*argv[i]=='b') {
               wybor->kolor=2;
               wybor->wybrano_kolor++;
              }
              else if (*argv[i]=='s') {
               wybor->kolor=0;
               wybor->wybrano_kolor++;
               wybor->konwersja_szarosci=1;
              }
              else   {
               return B_BLEDNYKOLOR;
              }
             }
             else
              return B_KOLORU;             
             break;
   case 'p': if (++i<argc) {
	            if (sscanf(argv[i],"%f",&wybor->w_prog)==1) {
               if (wybor->w_prog<=100 && wybor->w_prog>=0) {
	              wybor->progowanie=1;
                wybor->tablica[j]='p';
                j++;
               }
               else 
                return B_ZLAWARTOSC; }
              else
	             return B_BRAKWARTOSCI; }
             else 
	            return B_BRAKWARTOSCI;
             break;
   case 'c': if (++i<argc) {
	            if (sscanf(argv[i],"%f",&wybor->w_progc)==1) {
               if (wybor->w_progc<=100 && wybor->w_progc>=0) {
	              wybor->polprogowanie_czerni=1;
                wybor->tablica[j]='c';
                j++;
               }
               else 
                return B_ZLAWARTOSC; }
              else
	             return B_BRAKWARTOSCI; }
             else 
	            return B_BRAKWARTOSCI;
             break;
   case 'b': if (++i<argc) {
	            if (sscanf(argv[i],"%f",&wybor->w_progb)==1) {
               if (wybor->w_progb<=100 && wybor->w_progb>=0) {
	              wybor->polprogowanie_bieli=1;
                wybor->tablica[j]='b';
                j++;
               }
               else 
                return B_ZLAWARTOSC; }
              else
	             return B_BRAKWARTOSCI; }
             else 
	            return B_BRAKWARTOSCI;
             break;
   case 'g': if (++i<argc) {
	            if (sscanf(argv[i],"%f",&wybor->w_gamma)==1) {
               if (wybor->w_gamma!=0) {
	              wybor->korekcja_gamma=1;
                wybor->tablica[j]='g';
                j++;
               }
               else 
                return B_ZLAWARTOSC; }
              else
	             return B_BRAKWARTOSCI; }
             else 
	            return B_BRAKWARTOSCI;
             break;
   case 'z': if (++i<argc) {
	            if (sscanf(argv[i],"%f",&wybor->nowy_bieli)==1) {
               if (++i<argc) {
                if (sscanf(argv[i],"%f",&wybor->nowy_czerni)==1) {
	               wybor->zmiana_poziomow=1;
                 wybor->tablica[j]='z';
                 j++;
                }
                else
                 return B_BRAKWARTOSCI; }
               else
                return B_BRAKWARTOSCI; }
              else
	             return B_BRAKWARTOSCI; }
             else 
	            return B_BRAKWARTOSCI;
             break;
   case 'n': wybor->negatyw=1;
             wybor->tablica[j]='n';
             j++;
             break;
   case 'k': wybor->konturowanie=1;
             wybor->tablica[j]='k';
             j++;
             break;
   case 'x': wybor->rozmywanie_poziome=1;
             wybor->tablica[j]='x';
             j++;
             break;
   case 'y': wybor->rozmywanie_pionowe=1;
             wybor->tablica[j]='y';
             j++;
             break;
   case 'r': wybor->rozciaganie=1;
             wybor->tablica[j]='r';
             j++;
             break;
   case 'd': wybor->wyswietlenie=1;
             break;
   default:  return B_NIEPOPRAWNAOPCJA;
  } /* koniec switch */
 } /* koniec for */

 wybor->rozmiar=j; //okreslenie ilosci opcji do rozpatrzenia

 if (wybor->plik_we!=NULL)     /* ok: wej. strumien danych zainicjowany */
  return W_OK;
 else 
  return B_BRAKPLIKU;         /* blad:  nie otwarto pliku wejsciowego  */
 
}

int czytaj(t_obraz *obraz, t_opcje *wybor) {
  char buf[DL_LINII];     /*bufor pomocniczy do czytania naglowka i komentarzy */ 
  int znak;               /*zmienna pomocnicza do czytania komentarzy          */
  int koniec=0;           /*zmienna oznaczajaca koniec danych w pliku          */                
  int i,j;                /*iteratory tablic                                   */

/*Sprawdzenie czy podano prawidłowy uchwyt pliku */
  if (wybor->plik_we==NULL) {
    fprintf(stderr,"Blad: Nie podano uchwytu do pliku\n");
    return(0);  }

  if (fgets(buf,DL_LINII,wybor->plik_we)==NULL)   /* Wczytanie pierwszej linii pliku do bufora */
    koniec=1;                                     /* Nie udalo sie? Koniec danych!             */

  if ( (buf[0]!='P') && ((buf[1]!='2') || (buf[1]!='3'))) {  /* Czy jest magiczne "P2" lub "P3"? */
   fprintf(stderr,"Blad: To nie jest format obslugiwany przez program!\n");
   return(0);   }
/* zapisanie informacji o typie pliku */
  if (buf[1]=='2') {
   obraz->wspolczynnik=1;
   obraz->znak='2';
  }
  if (buf[1]=='3') {
   obraz->wspolczynnik=3;
   obraz->znak='3';
  }
  
  do {
   if ((znak=fgetc(wybor->plik_we))=='#') {         /* Czy linia rozpoczyna sie od znaku '#'? */
    if (fgets(buf,DL_LINII,wybor->plik_we)==NULL)   /* Przeczytaj ja do bufora                */
	   koniec=1;                               /* Zapamietaj ewentualny koniec danych */
   }  
   else
    ungetc(znak,wybor->plik_we); /* Gdy przeczytany znak z poczatku linii nie jest '#' zwroc go */
  } while (znak=='#' && !koniec);   /* Powtarzaj dopoki sa linie komentarza */
                                    /* i nie nastapil koniec danych         */

  if (fscanf(wybor->plik_we,"%d %d %d",&obraz->wymx,&obraz->wymy,&obraz->szarosci)!=3) {
   fprintf(stderr,"Blad: Brak wymiarow obrazu lub liczby stopni szarosci\n");
   return(0);  
  }
/* ustalenie rozmiaru tablicy i jej dynamiczna alokacja */
  obraz->nowy_wymx = obraz->wspolczynnik * obraz->wymx;

  obraz->piksele = (int**)malloc(obraz->wymy*sizeof(int*));
  for (i=0; i<obraz->wymy; ++i) {
   obraz->piksele[i] = (int*)malloc(obraz->nowy_wymx*sizeof(int));
  }
  for (i=0; i< (obraz->wymy); i++) {
   for (j=0; j < obraz->nowy_wymx; j++) {
    if (fscanf(wybor->plik_we,"%d", &obraz->piksele[i][j])!=1) {
     fprintf(stderr,"Blad: Niewlasciwa wartosc pikseli.\n");
     return(0);
    } 
   }
  }
 return obraz->wymy * obraz->nowy_wymx; /* Czytanie zakonczone sukcesem, zwroc liczbe wczytanych pikseli */
}

int zapis (t_obraz *obraz, t_opcje *wybor){
 int i,j;

/*Sprawdzenie czy podano prawidłowy uchwyt pliku */
 if (wybor->plik_wy==NULL) {
  fprintf(stderr,"Blad: Nie podano uchwytu do pliku\n");
  return 0;  }
  
/* sekwencja wpisania parametrow obrazu do pliku */
 fprintf(wybor->plik_wy,"P%c\n%d %d\n%d\n",obraz->znak,obraz->wymx,obraz->wymy,obraz->szarosci);

/* sekwencja kopiowania obrazu piksel po pikselu */
  for (i=0;i<obraz->wymy;i++) {
   for (j=0;j<obraz->nowy_wymx;j++) {
    if (j%15==0)
     fprintf(wybor->plik_wy,"\n");
    fprintf(wybor->plik_wy,"%3d ",obraz->piksele[i][j]);
   }
  fprintf(wybor->plik_wy,"\n");
  } 
 return obraz->wymy * obraz->nowy_wymx;
}


void wyswietl(t_opcje *wybor) {
  char polecenie[DL_LINII];      /* bufor pomocniczy do zestawienia polecenia */

  strcpy(polecenie,"display ");  /* konstrukcja polecenia postaci */
  strcat(polecenie,wybor->nazwa_wyj);     /* display "nazwa_pliku" &       */
  strcat(polecenie," &");
  printf("%s\n",polecenie);      /* wydruk kontrolny polecenia */
  system(polecenie);             /* wykonanie polecenia        */
}

void rozpoznaj_blad (int kod){
 switch (kod){
   case B_NIEPOPRAWNAOPCJA: printf("Blad: Niepoprawna opcja.\n");
                            break;
   case B_BRAKNAZWY:        printf("Blad: Brak nazwy.\n");
                            break;
   case B_BRAKWARTOSCI:     printf("Blad: Brak wymaganej wartosci.\n");
                            break;
   case B_BRAKPLIKU:        printf("Blad: Brak wskazanego pliku.\n");
                            break;
   case B_KOLORU:           printf("Blad: Nie podano koloru przetwarzania.\n");
                            break;
   case B_BLEDNYKOLOR:      printf("Blad: Nie rozpoznano koloru przetwarzania.\n");
                            break;
   case B_ZLAWARTOSC:       printf("Blad: Nieprawidlowa wartosc parametru.\n");
                            break;
   case 0:                  printf("Opcje poprawne.\n");
                            break;
   
 }
}

void konwersja_szarosci (t_obraz *obraz,t_opcje *wybor) {
/*rezerwacja pamieci dla tymczasowej tablicy */
 obraz->piksele_temp = (int**)malloc(obraz->wymy*sizeof(int*));
 for (int i=0; i<obraz->wymy; ++i) {
  obraz->piksele_temp[i] = (int*)malloc(obraz->wymx*sizeof(int));
 }

/*kopiowanie danych do tymczasowej tablicy */
 for (int i=0;i<obraz->wymy;i++){
  for (int j=0;j<obraz->wymx;j++){
   obraz->piksele_temp[i][j]=
      (obraz->piksele[i][j*3]+obraz->piksele[i][j*3+1]+obraz->piksele[i][j*3+2])/3; 
  }
 }

/*zwolnienie pamieci starej tablicy i stworzenie nowej pod taka sama nazwa */
 free(obraz->piksele);
 obraz->piksele = (int**)malloc(obraz->wymy*sizeof(int*));
 for (int i=0; i<obraz->wymy; ++i) {
  obraz->piksele[i] = (int*)malloc(obraz->wymx*sizeof(int));
 }
 
/*kopiowanie danych z tablicy tymczasowej do nowej tablicy */
 for (int i=0;i<obraz->wymy;i++){
  for (int j=0;j<obraz->wymx;j++){
   obraz->piksele[i][j]=obraz->piksele_temp[i][j]; 
  }
 }
 free(obraz->piksele_temp);
 obraz->znak='2';
}