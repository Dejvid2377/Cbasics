#include <stdio.h>
#include <stdlib.h>
#include "funkcje.h"

void init (struct stos *glowa){
 glowa = NULL;  
}

struct stos *push (struct stos *glowa, int informacja){
 //przydzielenie pamieci dla nastepnego elementu stosu
 struct stos *tmp = (struct stos*)malloc(sizeof(struct stos));
 if (tmp==NULL) { //gdy nie udalo sie przydzielic pamieci
  exit(0); 
 }
 tmp->informacja = informacja; //zapisz wartosc elementu
 tmp->nastepny = glowa;        //powiazanie z poprzednim elementem stosu
 glowa = tmp;    //adres z nowo dodanym elementem staje sie glowa stosu
 return glowa;
}

struct stos *pop (struct stos *glowa, int *element){
 struct stos *tmp = glowa;    //tworzenie wskaznika na ostatni element
 *element = glowa->informacja;//odczytanie informacji o wartosci elementu
 glowa = glowa->nastepny;     //glowa stosu staje sie kolejny element
 free(tmp);                   //zwolnienie pamieci o poprzednim elemencie 
 return glowa;
}

void display (struct stos *glowa){
 struct stos *obecny;
 obecny = glowa; //przekazanie informacji o stosie do nowej zmiennej
 if (obecny != NULL) { //jezeli nie natrafilismy na koniec
  do {
   printf("%d\n",obecny->informacja); 
   obecny = obecny->nastepny; //wskazanie na kolejny element do odczytu
  } while (obecny!=NULL);     //wykonuj dopoki sa kolejne elementy stosu
 }
 else
  printf("dc: stack empty\n");
}

int puste(struct stos *glowa)
{
    return glowa == NULL ? 1 : 0;   //1 gdy stos jest pusty, 0 gdy nie
}

void zeruj_opcje (pomocnik *opcje) {
  opcje->ilosc = 0;
  opcje->koniec_programu = 1;
}