//zwolnij pamiec
//rozbuduj zeruj opcje
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "funkcje.h"
#include "zmienne_pomocnicze.h"

int main(){
  struct stos *glowa = NULL;
  pomocnik opcje;
  init(glowa);

  zeruj_opcje(&opcje);

//przydzielenie pamieci dla bufora odpowiadajacego za przechowywanie danych z stdin
  opcje.rozmiar = 30;
  opcje.buffer = (char *) malloc(opcje.rozmiar * sizeof(char));
  if (opcje.buffer == NULL){
    printf("Nie udalo sie przydzielic pamieci.");
    exit(1);
  }
  do {
    getline(&opcje.buffer,&opcje.rozmiar,stdin); //zczytaj wprowadzony znak

    if (sscanf(opcje.buffer,"%d", &opcje.element)==1) //jesli jest liczba
      glowa = push (glowa,opcje.element);             //umiesc ja na gorze stosu
    
    else if (sscanf(opcje.buffer,"%c", &opcje.znak)==1) { //jesli jest znakiem
        switch (opcje.znak) {                             //rozpatrz znak
          case '+': glowa = pop (glowa,&opcje.element);   //zdejmij element z gory stosu
                    opcje.tmp1 = opcje.element;           //przypisz jego wartosc do zmiennej
                    glowa = pop (glowa,&opcje.element);   //zdejmij kolejny element ze stosu
                    opcje.tmp2 = opcje.element;           //przypisz jego wartosc do zmiennej
                    opcje.element = opcje.tmp2 + opcje.tmp1;  //wykonaj operacje na zdjetych wartosciach
                    glowa = push (glowa,opcje.element);   //umiesc wynik na gorze stosu
                    break;
          case '-': glowa = pop (glowa,&opcje.element);   //pozostale funkcje dzialaja w analogiczny sposob
                    opcje.tmp1 = opcje.element;
                    glowa = pop (glowa,&opcje.element);
                    opcje.tmp2 = opcje.element;
                    opcje.element = opcje.tmp2 - opcje.tmp1;
                    glowa = push (glowa,opcje.element);
                    break;
          case '*': glowa = pop (glowa,&opcje.element);
                    opcje.tmp1 = opcje.element;
                    glowa = pop (glowa,&opcje.element);
                    opcje.tmp2 = opcje.element;
                    opcje.element = opcje.tmp2 * opcje.tmp1;
                    glowa = push (glowa,opcje.element);
                    break;
          case '/': glowa = pop (glowa,&opcje.element);
                    opcje.tmp1 = opcje.element;
                    glowa = pop (glowa,&opcje.element);
                    opcje.tmp2 = opcje.element;
                    opcje.element = opcje.tmp2 / opcje.tmp1;
                    glowa = push (glowa,opcje.element);
                    break;
          case 'p': printf("%d\n",opcje.element); //wyswietl ostatni (gorny element stosu)  
                    break;
          case 'P': glowa = pop (glowa,&opcje.element); //zdjemij ostatni element
                    break;
          case 'r': glowa = pop (glowa,&opcje.element); //zamien miejscami dwa ostatnie elementy
                    opcje.tmp1 = opcje.element;
                    glowa = pop (glowa,&opcje.element);
                    opcje.tmp2 = opcje.element;
                     opcje.tmp3 = opcje.tmp1; 
                     opcje.tmp1 = opcje.tmp2; 
                     opcje.tmp2 = opcje.tmp3;
                    glowa = push (glowa,opcje.tmp2);
                    glowa = push (glowa,opcje.tmp1);
                    break;
          case 'd': glowa = push (glowa,opcje.element); //kopiuj ostatni element i umiesc go na  stosie
                    break;
          case 'f': display(glowa);   //wyswietl stos
                    break;
          case 'c': while (puste(glowa)==0){  //usun wszystkie elementy stosu
                      glowa = pop (glowa,&opcje.element);
                    }
                    break;
          case 'q': opcje.koniec_programu=0;    //wyjdz z programu
                    break;
          default : printf("Nierozpoznana opcja.\n");
                    break;
        }  
    }
    else
     printf("Blad czytania danych z bufora\n");   
  } while (opcje.koniec_programu);

  free(opcje.buffer);
  return 0;
}