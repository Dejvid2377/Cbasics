#ifndef ZMIENNE_POMOCNICZE_H
#define ZMIENNE_POMOCNICZE_H

struct stos{
 int informacja;
 struct stos *nastepny;
};

typedef struct{
 char *buffer; //wskaznik na obszar typu char
 size_t rozmiar; //przyszly rozmiar dla bufora (tylko dodatnie)
 char znak;      //zmienna dla wybranej opcji
 int ilosc,element,koniec_programu;
 int tmp1,tmp2,tmp3;
} pomocnik;

#endif