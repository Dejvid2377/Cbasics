#ifndef FUNKCJE_H
#define FUNKCJE_H
#include "zmienne_pomocnicze.h"

/************************************************************************************
 * Funkcja inicjuje glowe stosu (pusta lista do ktorej mamy od teraz mozliwosc      *
 * odnoszenia sie)                                                  	       	    *
 *										                                            *
 * \param[in] wskaznik na strukture stosu	                                        *
 * \param[out] zainicjowana struktura stosu                                         *
 ************************************************************************************/
void init (struct stos *glowa);

/************************************************************************************
 * Funkcja dodaje na szczyt stosu (jej ostatni element) wskazany obiekt             *                                     	       	    *
 *										                                            *
 * \param[in] wskaznik na strukture stosu	                                        *
 * \param[in] element ktory chcemy dodac do stosu                                   *
 * \param[out] stos powiekszony o zadany element                                    *
 ************************************************************************************/
struct stos *push (struct stos *glowa, int informacja);

/************************************************************************************
 * Funkcja zdejmuje ze szczytu stosu (jej ostatni element) wskazany obiekt          *                                     	       	    *
 *										                                            *
 * \param[in] wskaznik na strukture stosu	                                        *
 * \param[in] wskaznik na element ktory chcemy zdjac ze stosu                       *
 * \param[out] stos pomniejszony o zadany element                                   *
 ************************************************************************************/
struct stos *pop (struct stos *glowa, int *element);

/************************************************************************************
 * Funkcja wyswietla wszystkie elementy stosu                                       *                                     	       	    *
 *										                                            *
 * \param[in] wskaznik na strukture stosu	                                        *
 * \param[out] wszystkie elementy stosu wyswietlone na standardowym wyjsciu         *
 ************************************************************************************/
void display (struct stos *glowa);

/************************************************************************************
 * Funkcja sprawdza czy stos nie jest pusty                                         *                                     	       	    *
 *										                                            *
 * \param[in] wskaznik na strukture stosu	                                        *
 * \param[out] wartosc logiczna 0 lub 1                                             *
 ************************************************************************************/
int puste(struct stos *glowa);

/************************************************************************************
 * Funkcja przywraca wybrane wartosci do stanu poczatkowego                         *                                     	       	    *
 *										                                            *
 * \param[in] wskaznik na strukture pomocnicza programu                             *
 * \param[out] zmienne o nowych wartosciach                                         *
 ************************************************************************************/
void zeruj_opcje(pomocnik *opcje);

#endif