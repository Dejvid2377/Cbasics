#ifndef ZMIENNE_POMOCNICZE_H
#define ZMIENNE_POMOCNICZE_H

#define MAX 5       //rozmiar boku kwadratu na ktorym znajduje sie pole gry
                    //mozna modyfikowac wedle potrzeby

typedef struct {    //tworzenie struktury okreslajacej wspolrzedne pola na tablicy do gry
 int x;
 int y;
}wspolrzedne;

#endif
